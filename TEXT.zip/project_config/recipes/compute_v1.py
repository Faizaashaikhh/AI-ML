# -*- coding: utf-8 -*-
import dataiku
import pandas as pd

# Load the dataset
input_dataset = dataiku.Dataset("vaccination_tweets")
df = input_dataset.get_dataframe()

# Print column names (for debugging — you can remove this line later)
print("Columns:", df.columns)

# Identify the text column — change this if needed
# Replace 'text' with your actual column name if different
TEXT_COLUMN = "text"  # <- UPDATE this if your column name is different

# Define keyword lists
positive_keywords = ['safe', 'effective', 'love', 'grateful', 'amazing', 'happy', 'relieved', 'thankful']
negative_keywords = ['dangerous', 'fake', 'hate', 'useless', 'bad', 'deadly', 'afraid', 'worried']

# Define sentiment scoring function
def simple_sentiment_score(text):
    text = str(text).lower()
    pos_hits = sum(1 for word in positive_keywords if word in text)
    neg_hits = sum(1 for word in negative_keywords if word in text)

    if neg_hits > pos_hits + 1:
        return 1  # Very Negative
    elif neg_hits > pos_hits:
        return 2  # Negative
    elif pos_hits == neg_hits:
        return 3  # Neutral
    elif pos_hits > neg_hits + 1:
        return 5  # Very Positive
    else:
        return 4  # Positive

# Apply the scoring
df['sentiment_score'] = df[TEXT_COLUMN].apply(simple_sentiment_score)

# Write to output
output_dataset = dataiku.Dataset("v1")
output_dataset.write_with_schema(df)